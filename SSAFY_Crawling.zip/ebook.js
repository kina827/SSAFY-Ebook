const FILE_NAME = "ebook";  // 이미지 파일 앞에 붙는 이름이에요 마음대로 수정해도 됩니다.
                            // ex) ebook_0001.jpg 형식으로 저장됨 (38 라인 참고하세요)
const DIR = "";             // original_link.txt에서 다운로드받고싶은 파일 정보 붙여넣기하세요
const MAX_PAGE = ;          // original_link.txt에서 다운로드받고싶은 파일 정보 붙여넣기하세요
const BASE_URL = "";        // original_link.txt에서 다운로드받고싶은 파일 정보 붙여넣기하세요

function num2str(num){
    let tmp = num + "";
    let len = tmp.length;
    for(let i=len; i<4; i++){
        tmp = "0" + tmp;
    }
    return tmp;
}

const puppeteer = require("puppeteer");
const crawler = async () => {
    try{
        const browser = await puppeteer.launch({headless: true, args: ["--window-size=1920,1080"]});
        const page = await browser.newPage();
        // Login
        await page.setViewport({width: 1920, height: 1080})
        await page.goto("http://edu.ssafy.com/",{waitUntil: 'networkidle2'});
        await page.waitFor(5000);
        await page.evaluate(() => {
            document.querySelector("#userId").value = "여기에 에듀싸피 아이디를 입력하세요";
            document.querySelector("#userPwd").value = "여기에 에듀싸피 비밀번호를 입력하세요";
            document.querySelector("#wrap > div > div > div.section > form > div > div.field-set.log-in > div.form-btn > a").click();
        });
        await page.waitFor(1000);
        let links = [];
        for(let pageNo = 1; pageNo <=MAX_PAGE; pageNo++){
            links.push(`${BASE_URL}${num2str(pageNo)}.jpg`);
        }
        let pages = await Promise.all(links.map( async (li) => await browser.newPage()));
        await Promise.all(pages.map( async (page) => await page.setViewport({width: 1920, height: 1080})));
        idx = 0; await Promise.all(pages.map(async (page) => await page.goto(links[idx++], {waitUntil: "networkidle2"})));
        idx = 1; await Promise.all(pages.map((page) => page.screenshot({path: `${__dirname}/ebook/${DIR}/${FILE_NAME}_${num2str(idx++)}.jpg`, fullPage: true})));
        console.log(`files save at "${__dirname}/ebook/${DIR}/"`);
        await Promise.all(pages.map(async (page) => await page.close()));
        await page.close();
        await browser.close();
    }catch(error){
        console.log(error);
    }
}
crawler();